# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['server']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Cors>=3.0.10,<4.0.0',
 'Flask-Migrate>=3.1.0,<4.0.0',
 'Flask-SQLAlchemy>=2.5.1,<3.0.0',
 'Flask>=2.0.2,<3.0.0',
 'bson>=0.5.10,<0.6.0',
 'flask-marshmallow>=0.14.0,<0.15.0',
 'marshmallow-sqlalchemy>=0.26.1,<0.27.0',
 'psycopg2-binary>=2.9.2,<3.0.0',
 'requests>=2.26.0,<3.0.0']

setup_kwargs = {
    'name': 'server',
    'version': '0.1.0',
    'description': '',
    'long_description': 'None',
    'author': 'Shihan Cheng',
    'author_email': 'shihan.cheng@columbia.edu',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
